Font: Agency FB Bold
Download: https://fontzone.net/font-details/agencyfb-bold